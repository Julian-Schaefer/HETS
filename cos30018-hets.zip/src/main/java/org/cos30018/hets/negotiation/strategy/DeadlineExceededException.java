package org.cos30018.hets.negotiation.strategy;

public class DeadlineExceededException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9188740672013593784L;

}
