package org.cos30018.hets.negotiation.utility;

public abstract class CardinalUtility<T> {

	public abstract double getUtility(T input);

}
