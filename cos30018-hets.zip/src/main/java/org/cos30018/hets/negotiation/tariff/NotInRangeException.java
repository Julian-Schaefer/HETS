package org.cos30018.hets.negotiation.tariff;

public class NotInRangeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4868417718163066656L;

}
