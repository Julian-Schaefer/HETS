package org.cos30018.hets.util;

public class DoubleRange {
	public double firstValue;
	public double secondValue;

	public DoubleRange(double firstValue, double secondValue) {
		this.firstValue = firstValue;
		this.secondValue = secondValue;
	}
}
