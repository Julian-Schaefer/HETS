package org.cos30018.hets.logic.retailer;

public class RetailerMessage {
	public static final String REGISTER = "REGISTER RETAILER";
	public static final String UNREGISTER = "UNREGISTER RETAILER";
}
