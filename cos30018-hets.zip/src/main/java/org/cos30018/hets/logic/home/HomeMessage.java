package org.cos30018.hets.logic.home;

public class HomeMessage {
	public static final String ACCEPTED = "ACCEPTED";
	public static final String OK = "OK";
	

	public static final String ONTOLOGY_REGISTRATION = "REGISTRATION";
	public static final String ONTOLOGY_USAGE = "REGISTRATION";
}
