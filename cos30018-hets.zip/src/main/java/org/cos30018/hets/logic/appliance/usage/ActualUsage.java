package org.cos30018.hets.logic.appliance.usage;

public interface ActualUsage {

	double getActualUsage(int period);

}
