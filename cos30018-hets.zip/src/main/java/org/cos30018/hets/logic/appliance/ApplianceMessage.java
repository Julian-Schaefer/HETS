package org.cos30018.hets.logic.appliance;

public class ApplianceMessage {
	public static final String REGISTER = "REGISTER APPLIANCE";
	public static final String ACTUAL_USAGE = "ACTUAL_USAGE ";
	public static final String FORECAST = "FORECAST ";
	public static final String UNREGISTER = "UNREGISTER APPLIANCE";
}
